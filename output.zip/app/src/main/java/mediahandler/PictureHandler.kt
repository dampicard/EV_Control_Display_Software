package mediahandler

class PictureHandler {

}