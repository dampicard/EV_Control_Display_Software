package mediahandler

class VideoHandler {

	fun playVideo() {  }
}