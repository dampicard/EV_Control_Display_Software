package mediahandler

class MusicHandler {

}