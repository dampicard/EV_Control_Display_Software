package hardwarelowlevelapis

class VideoAPI {

	fun displayImage(image : Integer) {  }
	fun displayText(position : Integer, text : String) {  }
}