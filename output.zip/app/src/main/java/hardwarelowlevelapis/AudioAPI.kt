package hardwarelowlevelapis

class AudioAPI {

	fun soundUp() {  }
	fun soundDown() {  }
	fun playSound() {  }
}