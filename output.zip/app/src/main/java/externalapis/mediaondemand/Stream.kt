package externalapis.mediaondemand

class Stream {

}