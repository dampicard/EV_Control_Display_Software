package externalapis

class MediaQuery {

}